#include "ruutu.h"


Ruutu::Ruutu(int sarake, int rivi)
{
}


int Ruutu::getRivi()
{
	return 0;
}


int Ruutu::getSarake()
{
	return 0;
}


void Ruutu::setRivi(int rivi) 
{
	
}


void Ruutu::setSarake(int sarake) 
{

}
