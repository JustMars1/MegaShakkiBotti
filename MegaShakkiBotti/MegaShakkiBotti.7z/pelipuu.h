#include "asema.h"
#include "minMaxPaluu.h"
class Pelipuu {
public:
	MinMaxPaluu maxi(int syvyys, Asema* asema);
	MinMaxPaluu mini(int syvyys, Asema* asema);
};