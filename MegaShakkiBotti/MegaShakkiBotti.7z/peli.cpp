#include "peli.h"

using namespace std;


Peli::Peli(int ihmisenVari)
{
	
}


int Peli::getKoneenVari(){
	return 0;
}
